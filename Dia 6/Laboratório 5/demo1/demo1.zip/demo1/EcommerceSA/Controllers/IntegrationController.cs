﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace EcommerceSA.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IntegrationController : ControllerBase
    {
        private readonly IOptions<Integration> settings;

        public IntegrationController(IOptions<Integration> settings)
        {
            this.settings = settings;
        }

        [HttpGet]
        public string Get()
        {
            return this.settings.Value.EndPoint;
        }

    }
}
