﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace EcommerceSA.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {

        [HttpGet]
        public IEnumerable<Product> Get()
        {
            var products = new List<Product>();

            products.Add(new Product { Name = "Socket", Price = 10.0m });
            products.Add(new Product { Name = "T-Shirt", Price = 60.5m });

            return products;
        }

    }
}