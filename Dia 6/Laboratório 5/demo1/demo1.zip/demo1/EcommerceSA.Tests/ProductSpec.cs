using EcommerceSA.Controllers;
using System;
using System.Linq;
using Xunit;

namespace EcommerceSA.Tests
{
    public class ProductSpec
    {
        [Fact]
        public void ShouldContainProducts()
        {
            // Given
            var controller = new ProductController();

            // When
            var result = controller.Get().ToList();

            // Then
            Assert.True(result.Count == 2);

        }
    }
}
